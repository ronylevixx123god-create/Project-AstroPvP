/*
 * Decompiled with CFR 0.150.
 */
package me.ifamasssxd.cosmicduel.struct.enums;

public enum DuelType {
    ONE_VS_ONE, TWO_VS_TWO;

}

